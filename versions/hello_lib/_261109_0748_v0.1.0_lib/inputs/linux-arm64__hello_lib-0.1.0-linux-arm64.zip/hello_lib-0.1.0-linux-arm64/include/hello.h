/* hello.h —— 示例库的公开 C 接口（随包发，允许出现在公开仓） */
#ifndef HELLO_H
#define HELLO_H
#ifdef _WIN32
#  define HELLO_API __declspec(dllexport)
#else
#  define HELLO_API __attribute__((visibility("default")))
#endif
#ifdef __cplusplus
extern "C" {
#endif
HELLO_API const char *hello_version(void);
HELLO_API double hello_weighted_sum(const double *x, int n);
#ifdef __cplusplus
}
#endif
#endif
