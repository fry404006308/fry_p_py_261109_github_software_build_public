HelloApp v0.1.0（linux-x64）
================================================================
自带 Python 3.12.13，不需要安装任何东西、不改系统；整个文件夹放哪都能用，删掉即卸载。
运行：./HelloApp_v0.1.0_linux-x64/HelloApp        （没有图形桌面时自动用离屏模式）
Qt 需要的系统库（精简系统才要装）：sudo apt install libgl1 libegl1 libxkbcommon-x11-0 libxcb-cursor0 libfontconfig1 libdbus-1-3
