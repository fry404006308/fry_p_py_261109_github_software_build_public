# -*- coding: utf-8 -*-
# ★ fry_sbuild 源码保护编译生成的启动壳：原文件已编译成本平台原生扩展，这里只按「python 本文件 参数…」的老用法找到并调用它。
# 不含业务代码；入口用 isfile 判断它在不在
import importlib
import os
import sys


def _root():
    d = os.path.dirname(os.path.abspath(__file__))
    while not os.path.isfile(os.path.join(d, 'fry_sbuild_root.json')):
        p = os.path.dirname(d)
        if p == d:
            raise RuntimeError('找不到项目根（fry_sbuild_root.json）')
        d = p
    return d


if _root() not in sys.path:
    sys.path.insert(0, _root())
_M = importlib.import_module('worker')
globals().update({k: v for k, v in vars(_M).items() if not k.startswith('_')})
main = getattr(_M, 'main', None)

if __name__ == '__main__':
    raise SystemExit(_M.main(sys.argv[1:]))
