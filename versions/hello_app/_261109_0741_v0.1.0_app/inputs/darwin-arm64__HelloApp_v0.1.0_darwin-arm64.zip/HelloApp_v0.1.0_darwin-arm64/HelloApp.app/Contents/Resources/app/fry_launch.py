# -*- coding: utf-8 -*-
# fry_sbuild 生成的便携包入口：不含业务代码，只把运行时根加进 sys.path、调用入口模块的 main()
import importlib, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
os.environ.setdefault("FRY_APP_ROOT", HERE)
for r in reversed(['plugins', 'app', '']):
    p = os.path.join(HERE, r) if r else HERE
    if p not in sys.path:
        sys.path.insert(0, p)
if __name__ == "__main__":
    raise SystemExit(importlib.import_module('hello_entry').main())
